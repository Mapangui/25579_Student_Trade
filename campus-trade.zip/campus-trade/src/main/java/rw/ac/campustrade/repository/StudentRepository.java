package rw.ac.campustrade.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import rw.ac.campustrade.model.Student;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {
    
    // Derived queries
    Optional<Student> findByEmail(String email);
    Optional<Student> findByStudentId(String studentId);
    
    // Exists queries
    boolean existsByEmail(String email);
    boolean existsByStudentId(String studentId);
    
    // Location-based queries
    List<Student> findByLocationProvinceCode(String provinceCode);
    List<Student> findByLocationProvince(String province);
    
    // University queries
    List<Student> findByUniversity(String university);
    List<Student> findByUniversity(String university, Sort sort);
    Page<Student> findByUniversity(String university, Pageable pageable);
    
    // Major queries
    List<Student> findByMajor(String major);
    
    // Search queries
    List<Student> findByFirstNameContainingOrLastNameContaining(String firstName, String lastName);
}