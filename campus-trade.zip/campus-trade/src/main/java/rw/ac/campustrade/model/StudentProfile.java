package rw.ac.campustrade.model;

import jakarta.persistence.*;

@Entity
@Table(name = "student_profiles")
public class StudentProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 1000)
    private String bio;

    private String profilePictureUrl;
    private Double rating;
    private Integer totalTransactions;
    private Boolean isVerified;
    
    @Column(length = 500)
    private String interests;
    
    private String facebookProfile;
    private String twitterHandle;
    private String linkedinProfile;

    @OneToOne
    @JoinColumn(name = "student_id", unique = true)
    private Student student;

    // Constructors
    public StudentProfile() {}

    public StudentProfile(String bio, String profilePictureUrl, Double rating, 
                        Integer totalTransactions, Boolean isVerified, String interests, 
                        Student student) {
        this.bio = bio;
        this.profilePictureUrl = profilePictureUrl;
        this.rating = rating;
        this.totalTransactions = totalTransactions;
        this.isVerified = isVerified;
        this.interests = interests;
        this.student = student;
    }
    
    public StudentProfile(Long id, String bio, String profilePictureUrl, Double rating, 
                         Integer totalTransactions, Boolean isVerified, String interests,
                         String facebookProfile, String twitterHandle, String linkedinProfile, 
                         Student student) {
        this.id = id;
        this.bio = bio;
        this.profilePictureUrl = profilePictureUrl;
        this.rating = rating;
        this.totalTransactions = totalTransactions;
        this.isVerified = isVerified;
        this.interests = interests;
        this.facebookProfile = facebookProfile;
        this.twitterHandle = twitterHandle;
        this.linkedinProfile = linkedinProfile;
        this.student = student;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }

    public String getProfilePictureUrl() { return profilePictureUrl; }
    public void setProfilePictureUrl(String profilePictureUrl) { this.profilePictureUrl = profilePictureUrl; }

    public Double getRating() { return rating; }
    public void setRating(Double rating) { this.rating = rating; }

    public Integer getTotalTransactions() { return totalTransactions; }
    public void setTotalTransactions(Integer totalTransactions) { this.totalTransactions = totalTransactions; }

    public Boolean getIsVerified() { return isVerified; }
    public void setIsVerified(Boolean isVerified) { this.isVerified = isVerified; }

    public String getInterests() { return interests; }
    public void setInterests(String interests) { this.interests = interests; }

    public String getFacebookProfile() { return facebookProfile; }
    public void setFacebookProfile(String facebookProfile) { this.facebookProfile = facebookProfile; }

    public String getTwitterHandle() { return twitterHandle; }
    public void setTwitterHandle(String twitterHandle) { this.twitterHandle = twitterHandle; }

    public String getLinkedinProfile() { return linkedinProfile; }
    public void setLinkedinProfile(String linkedinProfile) { this.linkedinProfile = linkedinProfile; }

    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }
}