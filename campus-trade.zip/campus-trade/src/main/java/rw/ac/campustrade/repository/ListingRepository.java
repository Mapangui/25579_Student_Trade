package rw.ac.campustrade.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import rw.ac.campustrade.model.Listing;

import java.util.List;

@Repository
public interface ListingRepository extends JpaRepository<Listing, Long> {
    
    // Find listings by seller
    List<Listing> findBySellerId(Long sellerId);
    
    // Find listings by category
    List<Listing> findByCategoryId(Long categoryId);
    Page<Listing> findByCategoryId(Long categoryId, Pageable pageable);
    
    // Find listings by type
    List<Listing> findByType(Listing.ListingType type);
    
    // Find listings by status
    List<Listing> findByStatus(Listing.ListingStatus status);
    
    // Search listings by title or description
    List<Listing> findByTitleContainingOrDescriptionContaining(String title, String description);
    
    // Find listings by price range
    List<Listing> findByPriceBetween(Double minPrice, Double maxPrice);
    
    // Find available listings
    List<Listing> findByStatusOrderByCreatedAtDesc(Listing.ListingStatus status);
    
    // FIXED: Use Pageable instead of PageRequest
    Page<Listing> findByTitleContainingOrDescriptionContaining(String title, String description, Pageable pageable);
}