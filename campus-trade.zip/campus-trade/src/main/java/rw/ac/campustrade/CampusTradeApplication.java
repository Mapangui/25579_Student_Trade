package rw.ac.campustrade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampusTradeApplication {

    public static void main(String[] args) {
        SpringApplication.run(CampusTradeApplication.class, args);
        System.out.println("\n========================================");
        System.out.println("✅ CampusTrade API is running!");
        System.out.println("📍 Server: http://localhost:8080");
        System.out.println("📚 API Docs: http://localhost:8080/api");
        System.out.println("========================================\n");
    }
}