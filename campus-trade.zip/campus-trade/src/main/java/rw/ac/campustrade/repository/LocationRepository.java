package rw.ac.campustrade.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import rw.ac.campustrade.model.Location;

import java.util.List;
import java.util.Optional;

@Repository
public interface LocationRepository extends JpaRepository<Location, Long> {
    
    // Find locations by province
    List<Location> findByProvince(String province);
    
    // Find locations by province code
    List<Location> findByProvinceCode(String provinceCode);
    
    // Find location by village code
    Optional<Location> findByVillageCode(String villageCode);
    
    // Check if province exists
    boolean existsByProvince(String province);
    
    // Find locations by district
    List<Location> findByDistrict(String district);
}