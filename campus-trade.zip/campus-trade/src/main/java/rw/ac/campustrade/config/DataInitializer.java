package rw.ac.campustrade.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import rw.ac.campustrade.model.Category;
import rw.ac.campustrade.model.Listing;
import rw.ac.campustrade.model.Location;
import rw.ac.campustrade.model.Student;
import rw.ac.campustrade.model.StudentProfile;
import rw.ac.campustrade.repository.CategoryRepository;
import rw.ac.campustrade.repository.ListingRepository;
import rw.ac.campustrade.repository.LocationRepository;
import rw.ac.campustrade.repository.StudentProfileRepository;
import rw.ac.campustrade.repository.StudentRepository;

@Component
public class DataInitializer implements CommandLineRunner {
    
    @Autowired
    private LocationRepository locationRepository;
    
    @Autowired
    private StudentRepository studentRepository;
    
    @Autowired
    private CategoryRepository categoryRepository;
    
    @Autowired
    private ListingRepository listingRepository;
    
    @Autowired
    private StudentProfileRepository profileRepository;
    
    @Override
    public void run(String... args) {
        if (locationRepository.count() > 0) {
            System.out.println("✅ Data already initialized");
            return;
        }
        
        System.out.println("🔄 Initializing sample data...");
        
        // 1. Create Locations
        Location kigaliGasabo = new Location(
            "Kigali City", "01", "Gasabo", "0101", "Remera", "010101",
            "Rukiri I", "01010101", "Amahoro", "0101010101"
        );
        locationRepository.save(kigaliGasabo);
        
        Location kigaliKicukiro = new Location(
            "Kigali City", "01", "Kicukiro", "0102", "Niboye", "010201",
            "Nyanza", "01020101", "Kagugu", "0102010101"
        );
        locationRepository.save(kigaliKicukiro);
        
        Location southernHuye = new Location(
            "Southern Province", "02", "Huye", "0201", "Tumba", "020101",
            "Kabuye", "02010101", "Matyazo", "0201010101"
        );
        locationRepository.save(southernHuye);
        
        // 2. Create Categories
        Category textbooks = new Category("Textbooks", "University and college textbooks for all majors");
        categoryRepository.save(textbooks);
        
        Category electronics = new Category("Electronics", "Laptops, phones, calculators, and tech accessories");
        categoryRepository.save(electronics);
        
        Category tutoring = new Category("Tutoring Services", "Academic tutoring and study help");
        categoryRepository.save(tutoring);
        
        Category notes = new Category("Study Notes", "Class notes, summaries, and study guides");
        categoryRepository.save(notes);
        
        // 3. Create Students
        Student student1 = new Student(
            "Jean", "Kalisa", "jean.kalisa@student.edu", "S2021001", 
            "0788123456", "University of Rwanda", "Computer Science", 3, kigaliGasabo
        );
        studentRepository.save(student1);
        
        Student student2 = new Student(
            "Marie", "Uwase", "marie.uwase@student.edu", "S2021002", 
            "0788234567", "University of Rwanda", "Business Administration", 2, kigaliKicukiro
        );
        studentRepository.save(student2);
        
        Student student3 = new Student(
            "Eric", "Mutabazi", "eric.mutabazi@student.edu", "S2020015", 
            "0788345678", "AUCA", "Civil Engineering", 4, southernHuye
        );
        studentRepository.save(student3);
        
        // 4. Create Student Profiles
        StudentProfile profile1 = new StudentProfile(
            "Passionate CS student interested in web development and AI",
            "https://example.com/photos/jean.jpg", 4.8, 15, true,
            "Web Dev, Machine Learning, Basketball", student1
        );
        profileRepository.save(profile1);
        
        StudentProfile profile2 = new StudentProfile(
            "Business student with interest in entrepreneurship",
            "https://example.com/photos/marie.jpg", 5.0, 8, true,
            "Marketing, Finance, Dancing", student2
        );
        profileRepository.save(profile2);
        
        // 5. Create Listings
        Listing listing1 = new Listing(
            "Data Structures and Algorithms Textbook",
            "Used textbook in excellent condition. Covers all major algorithms and data structures.",
            25000.0, Listing.ListingType.TEXTBOOK, Listing.ListingStatus.AVAILABLE,
            "LIKE_NEW", "https://example.com/books/dsa.jpg", student1, textbooks
        );
        listingRepository.save(listing1);
        
        Listing listing2 = new Listing(
            "Lenovo ThinkPad Laptop - i5, 8GB RAM",
            "Reliable laptop perfect for programming and general studies.",
            450000.0, Listing.ListingType.LAPTOP, Listing.ListingStatus.AVAILABLE,
            "GOOD", "https://example.com/laptops/thinkpad.jpg", student1, electronics
        );
        listingRepository.save(listing2);
        
        Listing listing3 = new Listing(
            "Mathematics Tutoring - Calculus & Linear Algebra",
            "Experienced tutor offering one-on-one sessions.",
            15000.0, Listing.ListingType.TUTORING_SERVICE, Listing.ListingStatus.AVAILABLE,
            null, null, student2, tutoring
        );
        listingRepository.save(listing3);
        
        System.out.println("✅ Sample data initialized successfully!");
        System.out.println("📊 Created: 3 Locations, 4 Categories, 3 Students, 2 Profiles, 3 Listings");
    }
}