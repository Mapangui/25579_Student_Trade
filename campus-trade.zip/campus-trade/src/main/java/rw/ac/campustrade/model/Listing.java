package rw.ac.campustrade.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "listings")
public class Listing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(length = 2000, nullable = false)
    private String description;

    @Column(nullable = false)
    private Double price;

    @Enumerated(EnumType.STRING)
    private ListingType type;

    @Enumerated(EnumType.STRING)
    private ListingStatus status;

    private String condition;
    private String imageUrl;
    
    @Column(nullable = false)
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;
    private Integer viewCount;

    @ManyToOne
    @JoinColumn(name = "seller_id", nullable = false)
    private Student seller;

    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;

    // Constructors
    public Listing() {}

    public Listing(String title, String description, Double price, ListingType type, 
                  ListingStatus status, String condition, String imageUrl, 
                  Student seller, Category category) {
        this.title = title;
        this.description = description;
        this.price = price;
        this.type = type;
        this.status = status;
        this.condition = condition;
        this.imageUrl = imageUrl;
        this.seller = seller;
        this.category = category;
        this.createdAt = LocalDateTime.now();
        this.viewCount = 0;
    }

    public Listing(Long id, String title, String description, Double price, ListingType type, 
                   ListingStatus status, String condition, String imageUrl, LocalDateTime createdAt, 
                   LocalDateTime updatedAt, Integer viewCount, Student seller, Category category) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.price = price;
        this.type = type;
        this.status = status;
        this.condition = condition;
        this.imageUrl = imageUrl;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.viewCount = viewCount;
        this.seller = seller;
        this.category = category;
    }

    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        if (viewCount == null) {
            viewCount = 0;
        }
        if (status == null) {
            status = ListingStatus.AVAILABLE;
        }
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    public ListingType getType() { return type; }
    public void setType(ListingType type) { this.type = type; }

    public ListingStatus getStatus() { return status; }
    public void setStatus(ListingStatus status) { this.status = status; }

    public String getCondition() { return condition; }
    public void setCondition(String condition) { this.condition = condition; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    public Integer getViewCount() { return viewCount; }
    public void setViewCount(Integer viewCount) { this.viewCount = viewCount; }

    public Student getSeller() { return seller; }
    public void setSeller(Student seller) { this.seller = seller; }

    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }

    public enum ListingType {
        TEXTBOOK, TUTORIAL, TUTORING_SERVICE, ELECTRONICS,
        STATIONERY, NOTES, LAPTOP, PHONE, ACCOMMODATION, OTHER
    }

    public enum ListingStatus {
        AVAILABLE, SOLD, RESERVED, DELETED
    }
}