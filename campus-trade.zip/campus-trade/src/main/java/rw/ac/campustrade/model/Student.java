package rw.ac.campustrade.model;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "students")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String firstName;

    @Column(nullable = false)
    private String lastName;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false, unique = true)
    private String studentId;

    @Column(nullable = false)
    private String phoneNumber;

    @Column(nullable = false)
    private String university;

    private String major;

    private Integer yearOfStudy;

    @ManyToOne
    @JoinColumn(name = "location_id")
    private Location location;

    @OneToOne(mappedBy = "student", cascade = CascadeType.ALL)
    private StudentProfile profile;

    @ManyToMany
    @JoinTable(
        name = "student_study_groups",
        joinColumns = @JoinColumn(name = "student_id"),
        inverseJoinColumns = @JoinColumn(name = "study_group_id")
    )
    private Set<StudyGroup> studyGroups = new HashSet<>();

    @OneToMany(mappedBy = "seller", cascade = CascadeType.ALL)
    private Set<Listing> listings = new HashSet<>();

    // Constructors
    public Student() {}

    public Student(String firstName, String lastName, String email, String studentId, 
                  String phoneNumber, String university, String major, Integer yearOfStudy, 
                  Location location) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.studentId = studentId;
        this.phoneNumber = phoneNumber;
        this.university = university;
        this.major = major;
        this.yearOfStudy = yearOfStudy;
        this.location = location;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public String getUniversity() { return university; }
    public void setUniversity(String university) { this.university = university; }

    public String getMajor() { return major; }
    public void setMajor(String major) { this.major = major; }

    public Integer getYearOfStudy() { return yearOfStudy; }
    public void setYearOfStudy(Integer yearOfStudy) { this.yearOfStudy = yearOfStudy; }

    public Location getLocation() { return location; }
    public void setLocation(Location location) { this.location = location; }

    public StudentProfile getProfile() { return profile; }
    public void setProfile(StudentProfile profile) { this.profile = profile; }

    public Set<StudyGroup> getStudyGroups() { return studyGroups; }
    public void setStudyGroups(Set<StudyGroup> studyGroups) { this.studyGroups = studyGroups; }

    public Set<Listing> getListings() { return listings; }
    public void setListings(Set<Listing> listings) { this.listings = listings; }
}