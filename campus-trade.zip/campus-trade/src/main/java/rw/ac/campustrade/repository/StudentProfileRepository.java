package rw.ac.campustrade.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import rw.ac.campustrade.model.StudentProfile;

import java.util.Optional;

@Repository
public interface StudentProfileRepository extends JpaRepository<StudentProfile, Long> {
    
    // Find profile by student ID
    Optional<StudentProfile> findByStudentId(Long studentId);
    
    // Check if profile exists for student
    boolean existsByStudentId(Long studentId);
    
    // Find profile by student email (through student relationship)
    Optional<StudentProfile> findByStudentEmail(String email);
}