package rw.ac.campustrade.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import rw.ac.campustrade.model.Student;
import rw.ac.campustrade.repository.StudentRepository;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class StudentService {
    
    @Autowired
    private StudentRepository studentRepository;
    
    // CREATE
    public Student createStudent(Student student) {
        if (studentRepository.existsByEmail(student.getEmail())) {
            throw new RuntimeException("Email already exists");
        }
        if (studentRepository.existsByStudentId(student.getStudentId())) {
            throw new RuntimeException("Student ID already exists");
        }
        return studentRepository.save(student);
    }
    
    // READ
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }
    
    public Optional<Student> getStudentById(Long id) {
        return studentRepository.findById(id);
    }
    
    public Optional<Student> getStudentByEmail(String email) {
        return studentRepository.findByEmail(email);
    }
    
    // READ with Pagination
    public Page<Student> getStudentsByUniversity(String university, int page, int size) {
        return studentRepository.findByUniversity(university, PageRequest.of(page, size));
    }
    
    // READ with Sorting
    public List<Student> getStudentsByUniversitySorted(String university) {
        return studentRepository.findByUniversity(university, Sort.by(Sort.Direction.ASC, "firstName"));
    }
    
    // READ by Location
    public List<Student> getStudentsByProvinceCode(String provinceCode) {
        return studentRepository.findByLocationProvinceCode(provinceCode);
    }
    
    public List<Student> getStudentsByProvinceName(String province) {
        return studentRepository.findByLocationProvince(province);
    }
    
    public List<Student> searchStudents(String searchTerm) {
        return studentRepository.findByFirstNameContainingOrLastNameContaining(searchTerm, searchTerm);
    }
    
    // UPDATE
    public Student updateStudent(Long id, Student updatedStudent) {
        Student existing = studentRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Student not found"));
        
        existing.setFirstName(updatedStudent.getFirstName());
        existing.setLastName(updatedStudent.getLastName());
        existing.setPhoneNumber(updatedStudent.getPhoneNumber());
        existing.setUniversity(updatedStudent.getUniversity());
        existing.setMajor(updatedStudent.getMajor());
        existing.setYearOfStudy(updatedStudent.getYearOfStudy());
        existing.setLocation(updatedStudent.getLocation());
        
        return studentRepository.save(existing);
    }
    
    // DELETE
    public void deleteStudent(Long id) {
        if (!studentRepository.existsById(id)) {
            throw new RuntimeException("Student not found");
        }
        studentRepository.deleteById(id);
    }
    
    // Additional methods
    public boolean emailExists(String email) {
        return studentRepository.existsByEmail(email);
    }
    
    public List<Student> getStudentsByMajor(String major) {
        return studentRepository.findByMajor(major);
    }
}