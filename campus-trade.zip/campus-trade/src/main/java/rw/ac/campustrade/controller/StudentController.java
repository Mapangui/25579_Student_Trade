package rw.ac.campustrade.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import rw.ac.campustrade.model.Student;
import rw.ac.campustrade.service.StudentService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    @Autowired
    private StudentService studentService;

    // GET all students
    @GetMapping
    public List<Student> getAllStudents() {
        return studentService.getAllStudents();
    }

    // GET student by ID
    @GetMapping("/{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable Long id) {
        Optional<Student> student = studentService.getStudentById(id);
        return student.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    // CREATE new student
    @PostMapping
    public Student createStudent(@RequestBody Student student) {
        return studentService.createStudent(student);
    }

    // UPDATE student
    @PutMapping("/{id}")
    public ResponseEntity<Student> updateStudent(@PathVariable Long id, @RequestBody Student student) {
        try {
            Student updatedStudent = studentService.updateStudent(id, student);
            return ResponseEntity.ok(updatedStudent);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // DELETE student
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable Long id) {
        try {
            studentService.deleteStudent(id);
            return ResponseEntity.ok().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // GET students by province code
    @GetMapping("/province-code/{provinceCode}")
    public List<Student> getStudentsByProvinceCode(@PathVariable String provinceCode) {
        return studentService.getStudentsByProvinceCode(provinceCode);
    }

    // GET students by province name
    @GetMapping("/province-name/{province}")
    public List<Student> getStudentsByProvinceName(@PathVariable String province) {
        return studentService.getStudentsByProvinceName(province);
    }
    
    
 // Add this method to your StudentController.java
    @GetMapping("/province/{province}")
    public List<Student> getStudentsByProvince(@PathVariable String province) {
        return studentService.getStudentsByProvinceName(province);
    }
}