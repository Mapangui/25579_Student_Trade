package rw.ac.campustrade.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import rw.ac.campustrade.model.Listing;
import rw.ac.campustrade.repository.ListingRepository;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/listings")
public class ListingController {

    @Autowired
    private ListingRepository listingRepository;

    // GET all listings
    @GetMapping
    public List<Listing> getAllListings() {
        return listingRepository.findAll();
    }

    // GET listing by ID
    @GetMapping("/{id}")
    public ResponseEntity<Listing> getListingById(@PathVariable Long id) {
        Optional<Listing> listing = listingRepository.findById(id);
        return listing.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    // CREATE new listing
    @PostMapping
    public Listing createListing(@RequestBody Listing listing) {
        return listingRepository.save(listing);
    }

    // GET listings by category
    @GetMapping("/category/{categoryId}")
    public List<Listing> getListingsByCategory(@PathVariable Long categoryId) {
        return listingRepository.findByCategoryId(categoryId);
    }

    // GET available listings
    @GetMapping("/available")
    public List<Listing> getAvailableListings() {
        return listingRepository.findByStatus(Listing.ListingStatus.AVAILABLE);
    }

    // GET listings by price range
    @GetMapping("/price-range")
    public List<Listing> getListingsByPriceRange(
            @RequestParam Double min, 
            @RequestParam Double max) {
        return listingRepository.findByPriceBetween(min, max);
    }

    // SEARCH listings
    @GetMapping("/search")
    public List<Listing> searchListings(@RequestParam String title) {
        return listingRepository.findByTitleContainingOrDescriptionContaining(title, title);
    }

    // SEARCH with pagination - FIXED
    @GetMapping("/search-page")
    public Page<Listing> searchListingsWithPagination(
            @RequestParam String title,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size) {
        return listingRepository.findByTitleContainingOrDescriptionContaining(
            title, title, PageRequest.of(page, size));
    }
}