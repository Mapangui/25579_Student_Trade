package rw.ac.campustrade.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import rw.ac.campustrade.model.Location;
import rw.ac.campustrade.repository.LocationRepository;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/locations")
public class LocationController {

    @Autowired
    private LocationRepository locationRepository;

    // GET all locations
    @GetMapping
    public List<Location> getAllLocations() {
        return locationRepository.findAll();
    }

    // GET location by ID
    @GetMapping("/{id}")
    public ResponseEntity<Location> getLocationById(@PathVariable Long id) {
        Optional<Location> location = locationRepository.findById(id);
        return location.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    // CREATE new location
    @PostMapping
    public Location createLocation(@RequestBody Location location) {
        return locationRepository.save(location);
    }

    // GET locations by province code
    @GetMapping("/province/{provinceCode}")
    public List<Location> getLocationsByProvinceCode(@PathVariable String provinceCode) {
        return locationRepository.findByProvinceCode(provinceCode);
    }

    // GET locations by province name
    @GetMapping("/province-name/{province}")
    public List<Location> getLocationsByProvince(@PathVariable String province) {
        return locationRepository.findByProvince(province);
    }
}