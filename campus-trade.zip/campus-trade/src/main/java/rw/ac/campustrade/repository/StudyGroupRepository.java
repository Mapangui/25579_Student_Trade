package rw.ac.campustrade.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import rw.ac.campustrade.model.StudyGroup;

import java.util.List;

@Repository
public interface StudyGroupRepository extends JpaRepository<StudyGroup, Long> {
    
    // Find study groups by subject
    List<StudyGroup> findBySubject(String subject);
    
    // Find active study groups
    List<StudyGroup> findByIsActiveTrue();
    
    // Find study groups by creator
    List<StudyGroup> findByCreatorId(Long creatorId);
    
    // Find study groups containing name
    List<StudyGroup> findByNameContaining(String name);
}