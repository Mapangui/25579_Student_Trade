package rw.ac.campustrade.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "study_groups")
public class StudyGroup {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String name;
    
    @Column(length = 1000)
    private String description;
    
    @Column(nullable = false)
    private String subject;
    
    private String meetingSchedule;
    
    private String meetingLocation;
    
    private Integer maxMembers;
    
    @Column(nullable = false)
    private LocalDateTime createdAt;
    
    private Boolean isActive;
    
    @ManyToMany(mappedBy = "studyGroups")
    private Set<Student> members = new HashSet<>();
    
    @ManyToOne
    @JoinColumn(name = "creator_id")
    private Student creator;
    
    // Constructors
    public StudyGroup() {}
    
    public StudyGroup(String name, String description, String subject, Student creator) {
        this.name = name;
        this.description = description;
        this.subject = subject;
        this.creator = creator;
        this.isActive = true;
        this.createdAt = LocalDateTime.now();
    }
    
    public StudyGroup(Long id, String name, String description, String subject, 
                     String meetingSchedule, String meetingLocation, Integer maxMembers, 
                     LocalDateTime createdAt, Boolean isActive, Set<Student> members, Student creator) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.subject = subject;
        this.meetingSchedule = meetingSchedule;
        this.meetingLocation = meetingLocation;
        this.maxMembers = maxMembers;
        this.createdAt = createdAt;
        this.isActive = isActive;
        this.members = members;
        this.creator = creator;
    }
    
    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        if (isActive == null) {
            isActive = true;
        }
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }
    
    public String getMeetingSchedule() { return meetingSchedule; }
    public void setMeetingSchedule(String meetingSchedule) { this.meetingSchedule = meetingSchedule; }
    
    public String getMeetingLocation() { return meetingLocation; }
    public void setMeetingLocation(String meetingLocation) { this.meetingLocation = meetingLocation; }
    
    public Integer getMaxMembers() { return maxMembers; }
    public void setMaxMembers(Integer maxMembers) { this.maxMembers = maxMembers; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }
    
    public Set<Student> getMembers() { return members; }
    public void setMembers(Set<Student> members) { this.members = members; }
    
    public Student getCreator() { return creator; }
    public void setCreator(Student creator) { this.creator = creator; }
}