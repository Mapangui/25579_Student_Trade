package rw.ac.campustrade.model;

import jakarta.persistence.*;

@Entity
@Table(name = "locations")
public class Location {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String province;
    
    @Column(nullable = false)
    private String provinceCode;
    
    @Column(nullable = false)
    private String district;
    
    @Column(nullable = false)
    private String districtCode;
    
    @Column(nullable = false)
    private String sector;
    
    @Column(nullable = false)
    private String sectorCode;
    
    @Column(nullable = false)
    private String cell;
    
    @Column(nullable = false)
    private String cellCode;
    
    @Column(nullable = false)
    private String village;
    
    @Column(nullable = false)
    private String villageCode;
    
    // Constructors
    public Location() {}
    
    public Location(String province, String provinceCode, String district, 
                   String districtCode, String sector, String sectorCode,
                   String cell, String cellCode, String village, String villageCode) {
        this.province = province;
        this.provinceCode = provinceCode;
        this.district = district;
        this.districtCode = districtCode;
        this.sector = sector;
        this.sectorCode = sectorCode;
        this.cell = cell;
        this.cellCode = cellCode;
        this.village = village;
        this.villageCode = villageCode;
    }
    
    public Location(Long id, String province, String provinceCode, String district, 
                   String districtCode, String sector, String sectorCode,
                   String cell, String cellCode, String village, String villageCode) {
        this.id = id;
        this.province = province;
        this.provinceCode = provinceCode;
        this.district = district;
        this.districtCode = districtCode;
        this.sector = sector;
        this.sectorCode = sectorCode;
        this.cell = cell;
        this.cellCode = cellCode;
        this.village = village;
        this.villageCode = villageCode;
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getProvince() { return province; }
    public void setProvince(String province) { this.province = province; }
    
    public String getProvinceCode() { return provinceCode; }
    public void setProvinceCode(String provinceCode) { this.provinceCode = provinceCode; }
    
    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }
    
    public String getDistrictCode() { return districtCode; }
    public void setDistrictCode(String districtCode) { this.districtCode = districtCode; }
    
    public String getSector() { return sector; }
    public void setSector(String sector) { this.sector = sector; }
    
    public String getSectorCode() { return sectorCode; }
    public void setSectorCode(String sectorCode) { this.sectorCode = sectorCode; }
    
    public String getCell() { return cell; }
    public void setCell(String cell) { this.cell = cell; }
    
    public String getCellCode() { return cellCode; }
    public void setCellCode(String cellCode) { this.cellCode = cellCode; }
    
    public String getVillage() { return village; }
    public void setVillage(String village) { this.village = village; }
    
    public String getVillageCode() { return villageCode; }
    public void setVillageCode(String villageCode) { this.villageCode = villageCode; }
}